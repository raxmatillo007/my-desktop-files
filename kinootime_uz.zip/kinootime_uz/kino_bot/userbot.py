import asyncio
import logging

from pyrogram import Client
from pyrogram.errors import FloodWait, RPCError


API_ID = 32919037
API_HASH = "a90b254a9d4a19d375cac480321e803b"
SESSION_NAME = "my_personal_migration_session"

SOURCE_CHAT_IDS = [-1001781505469]  # Replace with source channel IDs
DESTINATION_CHAT_ID = -1003773297585 # Put the destination channel ID here (starting with -100)

MAX_RETRIES = 3

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)
logger = logging.getLogger("telegram_migration")


async def copy_video(message, destination_chat_id: int) -> bool:
    for attempt in range(1, MAX_RETRIES + 1):
        try:
            await message.copy(chat_id=destination_chat_id)
            logger.info("Copied video from message %s", message.id)
            return True
        except FloodWait as exc:
            delay = exc.value + 1
            logger.warning(
                "FloodWait copying message %s; retrying in %s seconds",
                message.id,
                delay,
            )
            await asyncio.sleep(delay)
        except RPCError:
            logger.exception("Telegram error copying message %s; skipping", message.id)
            return False
        except Exception:
            if attempt == MAX_RETRIES:
                logger.exception(
                    "Failed to copy message %s after %s attempts; skipping",
                    message.id,
                    MAX_RETRIES,
                )
                return False

            delay = attempt * 2
            logger.exception(
                "Error copying message %s; retrying in %s seconds",
                message.id,
                delay,
            )
            await asyncio.sleep(delay)

    return False


async def migrate(app: Client) -> None:
    for source_chat_id in SOURCE_CHAT_IDS:
        logger.info("Starting migration from source channel %s", source_chat_id)
        offset_id = 0

        while True:
            try:
                async for message in app.get_chat_history(
                    chat_id=source_chat_id,
                    offset_id=offset_id,
                ):
                    offset_id = message.id
                    if message.video:
                        await copy_video(message, DESTINATION_CHAT_ID)
                break
            except FloodWait as exc:
                delay = exc.value + 1
                logger.warning(
                    "FloodWait reading source channel %s; retrying in %s seconds",
                    source_chat_id,
                    delay,
                )
                await asyncio.sleep(delay)
            except RPCError:
                logger.exception(
                    "Telegram error reading source channel %s; skipping it",
                    source_chat_id,
                )
                break
            except Exception:
                logger.exception(
                    "Unexpected error reading source channel %s; skipping it",
                    source_chat_id,
                )
                break


async def main() -> None:
    if not SOURCE_CHAT_IDS or DESTINATION_CHAT_ID is None:
        raise ValueError("Set SOURCE_CHAT_IDS and DESTINATION_CHAT_ID before running.")

    async with Client(
        SESSION_NAME,
        api_id=API_ID,
        api_hash=API_HASH,
    ) as app:
        await migrate(app)


if __name__ == "__main__":
    asyncio.run(main())