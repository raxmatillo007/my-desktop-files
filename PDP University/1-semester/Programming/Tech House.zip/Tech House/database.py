# shu fayl yordamida biz mahsulotlar, mijoz va sotuv ma'lumotlarini saqlaymiz .
# Ma'lumotlar ombori

mahsulotlar = [
    {
        "id": 1,
        "name": "Mikroto'lqinli pech",
        "price": 2_500_000,
        "status": "mavjud",
        "category": "Oshxona texnikasi"
     },
    {
        "id": 2,
        "name": "Changyutgich",
        "price": 3_500_000,
        "status": "mavjud",
        "category": "Tozalash texnikasi"
     },
    {
        "id": 3,
        "name": "Konditsioner",
        "price": 15_000_000,
        "status": "mavjud",
        "category": "Isitish va sovutish qurilmalari"
     },
    {
        "id": 4,
        "name": "Elektr soch qurutgichi",
        "price": 1_200_000,
        "status": "mavjud",
        "category": "Shaxsiy parvarish qurilmalari"
     },
    
    {
        "id": 5,
        "name": "Aqlli chiroq",
        "price": 800_000,
        "status": "mavjud",
        "category": "Aqilliy uy texnikasi"
     },

]

# Mijozlar ro'yxati
mijozlar_list = []

# Sotuvlar tarixi
sotuvlar_list = [] 

def init_db():
    pass

def mahsulotni_qidirish(sorov):
    return [mahsulot for mahsulot in mahsulotlar if sorov.lower() in mahsulot["name"].lower()]


def mahsulotni_idsi_olish(mahsulot_id):
    for mahsulot in mahsulotlar:
        if mahsulot["id"] == mahsulot_id:
            return mahsulot
    return None

def mahsulotlarni_kategoriyasi_olish(kategoriya):
    return [mahsulot for mahsulot in mahsulotlar if mahsulot['category'] == kategoriya]

def mahsulot_qoshish(name, price, category):
    yangi_id = len(mahsulotlar) + 1
    yangi_mahsulot = {
        "id": yangi_id,
        "name": name,
        "price": price,
        "status": "Mavjud",
        "category": category
    }
    mahsulotlar.append(yangi_mahsulot)
    return yangi_id


def mijoz_qoshish(ism, telefon, manzil, azolik, ballar):
    yangi_id = len(mijozlar_list) + 1
    yangi_mijoz = {
        "id": yangi_id,
        "ism": ism,
        "telefon": telefon,
        "manzil": manzil,
        "azolik": azolik,
        "ballar": ballar
    }
    mijozlar_list.append(yangi_mijoz)
    return yangi_id

def sotuv_qoshish(product_id, mijoz_id, sana):
    yangi_id = len(sotuvlar_list) + 1
    yangi_sotuv = {
        "id": yangi_id,
        "product_id": product_id,
        "mijoz_id": mijoz_id,
        "sana": sana
    }
    sotuvlar_list.append(yangi_sotuv)
    return True
   
def mahsulot_statusini_yangilash(mahsulot_id, yangi_status):
    for mahsulot in mahsulotlar:
        if mahsulot["id"] == str(mahsulot_id):
            mahsulot["status"] = yangi_status
            return True
    return False

def mijoz_tolovini_olish(mijoz_id):
   return [sotuv['product_id'] for sotuv in sotuvlar_list if sotuv['mijoz_id'] == mijoz_id]

def sotuvlar():
    return sotuvlar_list

def mijozlar():
    return mijozlar_list