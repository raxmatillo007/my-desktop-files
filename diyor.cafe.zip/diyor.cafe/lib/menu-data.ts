import type { LucideIcon } from "lucide-react"
import { LayoutGrid, Sandwich, Beef, Utensils, Drumstick, Popcorn } from "lucide-react"

export type Category = {
  id: string
  label: string
  icon: LucideIcon
}

export type FoodItem = {
  id: string
  title: string
  description: string
  price: number
  rating: number
  reviews: string
  image: string
  badge?: { label: string; tone: "amber" | "brand" }
  category: string
}

export const categories: Category[] = [
  { id: "all", label: "Hammasi", icon: LayoutGrid },
  { id: "lavash", label: "Lavashlar", icon: Sandwich },
  { id: "doner", label: "Doner", icon: Sandwich },
  { id: "burger", label: "Burgerlar", icon: Beef },
  { id: "hotdog", label: "Hot-doglar", icon: Utensils },
  { id: "kfc", label: "KFC", icon: Drumstick },
  { id: "fri", label: "Fri & Souslar", icon: Popcorn },
]

const menuItem = (id: string, title: string, price: number, category: string, image: string, description = "Yangi va mazali Diyor's Doner taomi"): FoodItem => ({
  id,
  title,
  description,
  price,
  rating: 4.8,
  reviews: "100+",
  image,
  category,
})

export const popularItems: FoodItem[] = [
  menuItem("lavash-standard", "Lavash Standard", 28000, "lavash", "/images/lavash-standard.png"),
  menuItem("lavash-achchiq", "Lavash (Achchiq)", 30000, "lavash", "/images/lavash-achchiq.png"),
  menuItem("lavash-sirli", "Lavash Sirli", 32000, "lavash", "/images/lavash-sirli.png"),
  menuItem("tandir-lavash", "Tandir Lavash", 35000, "lavash", "/images/tandir-lavash.png"),
  menuItem("lavash-max", "Lavash Max", 35000, "lavash", "/images/lavash-max.png"),
  menuItem("doner", "Doner", 27000, "doner", "/images/hero-doner.png"),
  menuItem("hotdog", "Hot-Dog", 10000, "hotdog", "/images/hotdog-klassik.png"),
  menuItem("hotdog-2x", "Hot-Dog 2X", 13000, "hotdog", "/images/hotdog-klassik.png"),
  menuItem("hotdog-canada", "Hot-Dog Canada", 15000, "hotdog", "/images/hotdog-canada.png"),
  menuItem("hotdog-canada-2x", "Hot-Dog Canada 2X", 18000, "hotdog", "/images/hotdog-canada.png"),
  menuItem("hotdog-chicken", "Hot-Dog Chicken", 17000, "hotdog", "/images/chicken-burger.png"),
  menuItem("hotdog-goshtli", "Hot-Dog Go'shtli", 18000, "hotdog", "/images/hero-doner.png"),
  menuItem("kfc-achchiq", "KFC (Achchiq)", 30000, "kfc", "/images/kfc-sershira.png"),
  menuItem("kfc-file-120", "KFC (File) 120 gr", 20000, "kfc", "/images/kfc-sershira.png"),
  menuItem("kfc-file-160", "KFC (File) 160 gr", 30000, "kfc", "/images/kfc-sershira.png"),
  menuItem("gamburger", "Gamburger", 25000, "burger", "/images/gamburger-max.png"),
  menuItem("chizburger", "Chizburger", 28000, "burger", "/images/chizburger.png"),
  menuItem("fri", "Fri", 15000, "fri", "/images/fri-kartoshka.png"),
  menuItem("chicken-burger", "Chicken Burger", 25000, "burger", "/images/chicken-burger.png"),
  menuItem("double-burger", "Double Burger", 35000, "burger", "/images/gamburger-max.png"),
  menuItem("xalapeno", "Xalapeno", 2000, "fri", "/images/fri-kartoshka.png"),
  menuItem("bulochka", "Bulochka", 2000, "fri", "/images/hotdog-klassik.png"),
  menuItem("sir", "Sir", 4000, "fri", "/images/pishloqli-lavash.png"),
  menuItem("chesnochnyi-sous", "Chesnochnıy (Oq)", 3000, "fri", "/images/souslar.png"),
  menuItem("tomatnyi-sous", "Tomatniy (Qizil)", 3000, "fri", "/images/souslar.png"),
  menuItem("sirniy-sous", "Sirniy Sous", 4000, "fri", "/images/souslar.png"),
]

export function getItemById(id: string): FoodItem | undefined {
  return popularItems.find((i) => i.id === id)
}

export function formatSom(price: number) {
  return `${price.toLocaleString("ru-RU").replace(/,/g, " ")} so'm`
}
